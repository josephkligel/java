/**
 * 
 */
/**
 * @author jkligel
 *
 */
module CareSoft {
}