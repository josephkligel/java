package com.ninja.zookeeper;

public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla gorilla = new Gorilla();
		
		// Throw three things
		gorilla.throwSomething();
		gorilla.throwSomething();
		gorilla.throwSomething();
		
		// Eat bananas twice
		gorilla.eatBananas();
		gorilla.eatBananas();
		
		// Climb
		gorilla.climb();
		
		// Display energy level
		gorilla.displayEnergy();
	}

}
