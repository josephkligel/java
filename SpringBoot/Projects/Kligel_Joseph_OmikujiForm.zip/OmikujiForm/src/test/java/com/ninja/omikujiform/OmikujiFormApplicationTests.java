package com.ninja.omikujiform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmikujiFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
